package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class tableCreate {
    static final String DB_URL = "jdbc:mysql://localhost:3306/BookShopManagement";
    static final String USER = "root";
    static final String PASS = "betul12345";
    
    public static void main(String[] args) {
        System.out.println("Gerekli tüm tablolar oluşturuluyor...");
        
        String[] sqlStatements = {
            
            "CREATE TABLE IF NOT EXISTS books (" +
            "book_id INT PRIMARY KEY AUTO_INCREMENT, " +
            "title VARCHAR(255) NOT NULL, " +
            "author VARCHAR(255) NOT NULL, " +
            "isbn VARCHAR(20) UNIQUE NOT NULL, " +
            "price DECIMAL(10, 2) NOT NULL, " +
            "quantity INT NOT NULL, " +
            "category VARCHAR(100), " +
            "publish_year INT, " +
            "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",
            
            "CREATE TABLE IF NOT EXISTS customers (" +
            "customer_id INT PRIMARY KEY AUTO_INCREMENT, " +
            "first_name VARCHAR(100) NOT NULL, " +
            "last_name VARCHAR(100) NOT NULL, " +
            "email VARCHAR(255) UNIQUE NOT NULL, " +
            "phone VARCHAR(20), " +
            "registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",
            
           
            "CREATE TABLE IF NOT EXISTS orders (" +
            "order_id INT PRIMARY KEY AUTO_INCREMENT, " +
            "customer_id INT NOT NULL, " +
            "order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
            "total_amount DECIMAL(10, 2) NOT NULL, " +
            "status VARCHAR(50) DEFAULT 'BEKLEMEDE', " +
            "FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE CASCADE)",
            
           
            "CREATE TABLE IF NOT EXISTS order_items (" +
            "order_item_id INT PRIMARY KEY AUTO_INCREMENT, " +
            "order_id INT NOT NULL, " +
            "book_id INT NOT NULL, " +
            "quantity INT NOT NULL, " +
            "unit_price DECIMAL(10, 2) NOT NULL, " +
            "total_price DECIMAL(10, 2) NOT NULL, " +
            "FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE, " +
            "FOREIGN KEY (book_id) REFERENCES books(book_id) ON DELETE CASCADE)"
        };
        
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             Statement stmt = conn.createStatement()) {
            
            for (int i = 0; i < sqlStatements.length; i++) {
                try {
                    stmt.executeUpdate(sqlStatements[i]);
                    System.out.println("✓ Tablo " + (i + 1) + " başarıyla kontrol edildi/oluşturuldu.");
                } catch (Exception e) {
                    System.err.println("✗ Tablo " + (i + 1) + " oluşturulurken hata: " + e.getMessage());
                }
            }
            System.out.println("\n✅ İşlem tamamlandı!");
            
            System.out.println("\n=== VERİTABANI GÜNCEL TABLO LİSTESİ ===");
            var rs = stmt.executeQuery("SHOW TABLES");
            int count = 0;
            while (rs.next()) {
                System.out.println("- " + rs.getString(1));
                count++;
            }
            System.out.println("Toplam tablo sayısı: " + count);   
        } catch (Exception e) {
            System.err.println("❌ Veritabanı bağlantı hatası:");
            e.printStackTrace();
        }
    }
}