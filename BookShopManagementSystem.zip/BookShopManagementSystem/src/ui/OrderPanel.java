package ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import model.Order;
import model.OrderItem;
import model.Book;
import service.OrderService;
import service.BookService;
import service.CustomerService;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;


@SuppressWarnings("serial")
public class OrderPanel extends JPanel {
    private JTable orderTable;
    private DefaultTableModel tableModel;
    private OrderService orderService;
    private BookService bookService;
    private CustomerService customerService;
    
    public OrderPanel() {
       
        Locale.setDefault(Locale.US);
        
        this.orderService = new OrderService();
        this.bookService = new BookService();
        this.customerService = new CustomerService();
        initializeUI();
        loadOrders();
    }
    
    private void initializeUI() {
        setLayout(new BorderLayout());
        
        
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JLabel titleLabel = new JLabel("Sipariş Yönetimi", SwingConstants.LEFT);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        topPanel.add(titleLabel, BorderLayout.WEST);
        
        add(topPanel, BorderLayout.NORTH);
        
       
        String[] columns = {"Sipariş No", "Müşteri", "Tarih", "Toplam Tutar", "Durum"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        orderTable = new JTable(tableModel);
        orderTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        orderTable.setRowHeight(25);
        JScrollPane scrollPane = new JScrollPane(orderTable);
        add(scrollPane, BorderLayout.CENTER);
        
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        
        JButton createButton = new JButton("Yeni Sipariş");
        JButton viewButton = new JButton("Detayları Gör");
        JButton updateStatusButton = new JButton("Durum Güncelle");
        JButton deleteButton = new JButton("Sipariş Sil");
        JButton refreshButton = new JButton("Yenile");
        
        createButton.addActionListener(e -> showCreateOrderDialog());
        viewButton.addActionListener(e -> viewOrderDetails());
        updateStatusButton.addActionListener(e -> updateOrderStatus());
        deleteButton.addActionListener(e -> deleteSelectedOrder());
        refreshButton.addActionListener(e -> loadOrders());
        
        buttonPanel.add(createButton);
        buttonPanel.add(viewButton);
        buttonPanel.add(updateStatusButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(refreshButton);
        
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    private void viewOrderDetails() {
        int selectedRow = orderTable.getSelectedRow();
        if (selectedRow >= 0) {
            Object orderId = tableModel.getValueAt(selectedRow, 0);
            String customerName = tableModel.getValueAt(selectedRow, 1).toString();
            String total = tableModel.getValueAt(selectedRow, 3).toString();
            String status = tableModel.getValueAt(selectedRow, 4).toString();
            
            String message = String.format(
                "Sipariş Detayları:\n\n" +
                "Sipariş No: %s\n" +
                "Müşteri: %s\n" +
                "Toplam Tutar: %s\n" +
                "Durum: %s",
                orderId, customerName, total, status
            );
            
            JOptionPane.showMessageDialog(this, message, "Sipariş Detayları", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Lütfen bir sipariş seçin!", "Uyarı", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    private void updateOrderStatus() {
        int selectedRow = orderTable.getSelectedRow();
        if (selectedRow >= 0) {
            int orderId = (int) tableModel.getValueAt(selectedRow, 0);
            String currentStatus = tableModel.getValueAt(selectedRow, 4).toString();
            
            String[] statusOptions = {"BEKLEMEDE", "HAZIRLANIYOR", "KARGODA", "TESLİM EDİLDİ", "İPTAL EDİLDİ"};
            String newStatus = (String) JOptionPane.showInputDialog(
                this, "Yeni durumu seçin:", "Sipariş Durumunu Güncelle",
                JOptionPane.QUESTION_MESSAGE, null, statusOptions, currentStatus
            );
            
            if (newStatus != null && !newStatus.equals(currentStatus)) {
                try {
                    if (orderService.updateOrderStatus(orderId, newStatus)) {
                        tableModel.setValueAt(newStatus, selectedRow, 4);
                        JOptionPane.showMessageDialog(this, "Sipariş durumu güncellendi!");
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(this, "Hata: " + e.getMessage(), "Hata", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Lütfen bir sipariş seçin!", "Uyarı", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    private void deleteSelectedOrder() {
        int selectedRow = orderTable.getSelectedRow();
        if (selectedRow >= 0) {
            int orderId = (int) tableModel.getValueAt(selectedRow, 0);
            int confirm = JOptionPane.showConfirmDialog(this, 
                orderId + " numaralı siparişi silmek istediğinize emin misiniz?", 
                "Onay", JOptionPane.YES_NO_OPTION);
            
            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    if (orderService.deleteOrder(orderId)) {
                        tableModel.removeRow(selectedRow);
                        JOptionPane.showMessageDialog(this, "Sipariş silindi!");
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(this, "Hata: " + e.getMessage(), "Hata", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }
    
    private void loadOrders() {
        tableModel.setRowCount(0);
        try {
            List<Order> orders = orderService.getAllOrders();
            for (Order order : orders) {
                tableModel.addRow(new Object[]{
                    order.getOrderId(),
                    order.getCustomerName() != null ? order.getCustomerName() : "Bilinmiyor",
                    order.getOrderDate(),
                    String.format("%.2f TL", order.getTotalAmount()),
                    order.getStatus()
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void showCreateOrderDialog() {
        JDialog dialog = new JDialog((Frame)SwingUtilities.getWindowAncestor(this), "Yeni Sipariş Oluştur", true);
        dialog.setSize(850, 600);
        dialog.setLocationRelativeTo(this);
        
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
       
        JComboBox<String> customerCombo = new JComboBox<>();
        customerCombo.addItem("-- Müşteri Seçin --");
        try {
            customerService.getAllCustomers().forEach(c -> 
                customerCombo.addItem(c.getCustomerId() + " - " + c.getFirstName() + " " + c.getLastName()));
        } catch (Exception e) { e.printStackTrace(); }
        
        JPanel customerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        customerPanel.add(new JLabel("Müşteri:"));
        customerPanel.add(customerCombo);
        
        
        DefaultTableModel cartModel = new DefaultTableModel(new String[]{"ID", "Kitap", "Miktar", "Birim Fiyat", "Toplam"}, 0);
        JTable cartTable = new JTable(cartModel);
        
        JComboBox<String> bookCombo = new JComboBox<>();
        bookCombo.addItem("-- Kitap Seçin --");
        Map<String, Book> bookMap = new HashMap<>();
        
        try {
            List<Book> allBooks = bookService.getAllBooks();
            for (Book b : allBooks) {
                if (b.getQuantity() > 0) {
                    String key = b.getTitle() + " (Stok: " + b.getQuantity() + ")";
                    bookCombo.addItem(key);
                    bookMap.put(key, b);
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
        
        JSpinner qtySpinner = new JSpinner(new SpinnerNumberModel(1, 1, 999, 1));
        JButton addBtn = new JButton("Ekle");
        JLabel totalLabel = new JLabel("Toplam: 0.00 TL");
        totalLabel.setFont(new Font("Arial", Font.BOLD, 14));
        
        addBtn.addActionListener(e -> {
            String selected = (String) bookCombo.getSelectedItem();
            Book book = bookMap.get(selected);
            int qty = (int) qtySpinner.getValue();
            
            if (book == null) return;
            if (qty > book.getQuantity()) {
                JOptionPane.showMessageDialog(dialog, "Yetersiz stok!");
                return;
            }
            
            
            boolean exists = false;
            for (int i = 0; i < cartModel.getRowCount(); i++) {
                if ((int)cartModel.getValueAt(i, 0) == book.getBookId()) {
                    int newQty = (int)cartModel.getValueAt(i, 2) + qty;
                    if (newQty > book.getQuantity()) {
                        JOptionPane.showMessageDialog(dialog, "Stok aşıldı!");
                        return;
                    }
                    cartModel.setValueAt(newQty, i, 2);
                    cartModel.setValueAt(String.format("%.2f TL", newQty * book.getPrice()), i, 4);
                    exists = true;
                    break;
                }
            }
            
            if (!exists) {
                cartModel.addRow(new Object[]{
                    book.getBookId(), book.getTitle(), qty, 
                    String.format("%.2f TL", book.getPrice()), 
                    String.format("%.2f TL", qty * book.getPrice())
                });
            }
            updateCartTotal(cartModel, totalLabel);
        });
        
        JPanel bookActionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bookActionPanel.add(bookCombo);
        bookActionPanel.add(new JLabel("Adet:"));
        bookActionPanel.add(qtySpinner);
        bookActionPanel.add(addBtn);
        
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(bookActionPanel, BorderLayout.NORTH);
        centerPanel.add(new JScrollPane(cartTable), BorderLayout.CENTER);
        centerPanel.add(totalLabel, BorderLayout.SOUTH);
              
        JButton saveBtn = new JButton("Siparişi Tamamla");
        saveBtn.addActionListener(e -> {
            if (customerCombo.getSelectedIndex() <= 0 || cartModel.getRowCount() == 0) {
                JOptionPane.showMessageDialog(dialog, "Müşteri ve ürün seçiniz!");
                return;
            }        
            try {
                int custId = Integer.parseInt(customerCombo.getSelectedItem().toString().split(" - ")[0]);
                Order order = new Order();
                order.setCustomerId(custId);
                order.setStatus("BEKLEMEDE");
                
                List<OrderItem> items = new ArrayList<>();
                double grandTotal = 0;
                
                for (int i = 0; i < cartModel.getRowCount(); i++) {
                    OrderItem item = new OrderItem();
                    item.setBookId((int) cartModel.getValueAt(i, 0));
                    item.setQuantity((int) cartModel.getValueAt(i, 2));
                    
                    String priceStr = cartModel.getValueAt(i, 3).toString().replace(" TL", "").replace(",", ".");
                    double price = Double.parseDouble(priceStr);
                    item.setUnitPrice(price);
                    
                    items.add(item);
                    grandTotal += (item.getQuantity() * price);
                }            
                order.setItems(items);
                order.setTotalAmount(grandTotal);
                
                if (orderService.createOrder(order)) {
                    JOptionPane.showMessageDialog(dialog, "Sipariş oluşturuldu!");
                    dialog.dispose();
                    loadOrders();
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Hata: " + ex.getMessage());
            }
        });    
        JPanel southPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        southPanel.add(saveBtn);
        
        mainPanel.add(customerPanel, BorderLayout.NORTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        mainPanel.add(southPanel, BorderLayout.SOUTH);
        
        dialog.add(mainPanel);
        dialog.setVisible(true);
    }  
    private void updateCartTotal(DefaultTableModel model, JLabel label) {
        double total = 0;
        for (int i = 0; i < model.getRowCount(); i++) {
            String s = model.getValueAt(i, 4).toString().replace(" TL", "").replace(",", ".");
            total += Double.parseDouble(s);
        }
        label.setText(String.format("Toplam: %.2f TL", total));
    }
}