package service;

import java.util.ArrayList;
import java.util.List;

import dao.BookDAO;
import dao.OrderDAO;
import model.Order;
import model.OrderItem;

public class OrderService {
    private OrderDAO orderDAO;
    private BookDAO bookDAO;
    
    public OrderService() {
        this.orderDAO = new OrderDAO();
        this.bookDAO = new BookDAO();
    }
    
    public boolean createOrder(Order order) {
        System.out.println("=== ORDER SERVICE: createOrder çağrıldı ===");
        
        try {
            if (order == null) {
                System.out.println("ERROR: Order null!");
                return false;
            }
            
            System.out.println("Müşteri ID: " + order.getCustomerId());
            System.out.println("Toplam Tutar: " + order.getTotalAmount());
            System.out.println("Durum: " + order.getStatus());
            
            if (order.getItems() == null) {
                System.out.println("ERROR: Order items null!");
                return false;
            }
            
            System.out.println("Sipariş öğe sayısı: " + order.getItems().size());
            
            for (OrderItem item : order.getItems()) {
                System.out.println("Öğe - Kitap ID: " + item.getBookId() + 
                                 ", Miktar: " + item.getQuantity() + 
                                 ", Fiyat: " + item.getUnitPrice());
            }
            System.out.println("Stok kontrolü yapılıyor...");
            for (OrderItem item : order.getItems()) {
                System.out.println("Kitap ID " + item.getBookId() + " için stok kontrolü");
                if (!bookDAO.updateStock(item.getBookId(), -item.getQuantity())) {
                    System.out.println("ERROR: Stok yetersiz! Kitap ID: " + item.getBookId());
                    return false;
                }
            }
            System.out.println("Stok kontrolü başarılı, sipariş kaydediliyor...");
            boolean result = orderDAO.create(order);
            System.out.println("Sipariş kayıt sonucu: " + result);
            
            return result;          
        } catch (Exception e) {
            System.err.println("Sipariş oluşturma hatası: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    } 
    public List<Order> getAllOrders() {
        try {
            List<Order> orders = orderDAO.readAll();
            
            return (orders != null) ? orders : new ArrayList<>();
        } catch (Exception e) {
            System.err.println("Siparişleri getirme hatası: " + e.getMessage());
            return new ArrayList<>();
        }
    }
    public boolean updateOrderStatus(int orderId, String status) {
        try {
            return orderDAO.updateOrderStatus(orderId, status);
        } catch (Exception e) {
            System.err.println("Durum güncelleme hatası: " + e.getMessage());
            return false;
        }
    }
    public boolean deleteOrder(int id) {
        try {
            return orderDAO.delete(id);
        } catch (Exception e) {
            System.err.println("Sipariş silme hatası: " + e.getMessage());
            return false;
        }
    }
}