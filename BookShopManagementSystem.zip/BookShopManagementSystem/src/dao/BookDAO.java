package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import database.veriTabani;
import model.Book;
import model.Customer;

public class BookDAO implements DAO<Book> {
    
    public boolean create(Book book) {
        String query = "INSERT INTO books (title, author, isbn, price, quantity, category, publish_year) " +
                      "VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = veriTabani.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setString(1, book.getTitle());
            pstmt.setString(2, book.getAuthor());
            pstmt.setString(3, book.getIsbn());
            pstmt.setDouble(4, book.getPrice());
            pstmt.setInt(5, book.getQuantity());
            pstmt.setString(6, book.getCategory());
            pstmt.setInt(7, book.getPublishYear());
            
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        book.setBookId(rs.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error creating book: " + e.getMessage());
        }
        return false;
    }

    public Book read1(int id) {
        String query = "SELECT * FROM books WHERE book_id = ?";
        Book book = null;
        
        try (Connection conn = veriTabani.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                book = new Book();
                book.setBookId(rs.getInt("book_id"));
                book.setTitle(rs.getString("title"));
                book.setAuthor(rs.getString("author"));
                book.setIsbn(rs.getString("isbn"));
                book.setPrice(rs.getDouble("price"));
                book.setQuantity(rs.getInt("quantity"));
                book.setCategory(rs.getString("category"));
                book.setPublishYear(rs.getInt("publish_year"));
            }
        } catch (SQLException e) {
            System.err.println("Error reading book: " + e.getMessage());
        }
        return book;
    }

    public List<Book> readAll() {
        List<Book> books = new ArrayList<>();
        String query = "SELECT * FROM books ORDER BY title";
        
        try (Connection conn = veriTabani.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                Book book = new Book();
                book.setBookId(rs.getInt("book_id"));
                book.setTitle(rs.getString("title"));
                book.setAuthor(rs.getString("author"));
                book.setIsbn(rs.getString("isbn"));
                book.setPrice(rs.getDouble("price"));
                book.setQuantity(rs.getInt("quantity"));
                book.setCategory(rs.getString("category"));
                book.setPublishYear(rs.getInt("publish_year"));
                books.add(book);
            }
        } catch (SQLException e) {
            System.err.println("Error reading all books: " + e.getMessage());
        }
        return books;
    }

    public boolean update(Book book) {
        String query = "UPDATE books SET title = ?, author = ?, isbn = ?, price = ?, " +
                      "quantity = ?, category = ?, publish_year = ? WHERE book_id = ?";
        
        try (Connection conn = veriTabani.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, book.getTitle());
            pstmt.setString(2, book.getAuthor());
            pstmt.setString(3, book.getIsbn());
            pstmt.setDouble(4, book.getPrice());
            pstmt.setInt(5, book.getQuantity());
            pstmt.setString(6, book.getCategory());
            pstmt.setInt(7, book.getPublishYear());
            pstmt.setInt(8, book.getBookId());
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating book: " + e.getMessage());
        }
        return false;
    }
    
    public boolean delete(int id) {
        String query = "DELETE FROM books WHERE book_id = ?";
        
        try (Connection conn = veriTabani.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting book: " + e.getMessage());
        }
        return false;
    }

    public List<Book> searchByTitle(String keyword) {
        List<Book> books = new ArrayList<>();
        String query = "SELECT * FROM books WHERE title LIKE ? ORDER BY title";
        
        try (Connection conn = veriTabani.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, "%" + keyword + "%");
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Book book = new Book();
                book.setBookId(rs.getInt("book_id"));
                book.setTitle(rs.getString("title"));
                book.setAuthor(rs.getString("author"));
                book.setIsbn(rs.getString("isbn"));
                book.setPrice(rs.getDouble("price"));
                book.setQuantity(rs.getInt("quantity"));
                book.setCategory(rs.getString("category"));
                book.setPublishYear(rs.getInt("publish_year"));
                books.add(book);
            }
        } catch (SQLException e) {
            System.err.println("Error searching books: " + e.getMessage());
        }
        return books;
    }
    
    public boolean updateStock(int bookId, int quantityChange) {
        String query = "UPDATE books SET quantity = quantity + ? WHERE book_id = ? AND quantity + ? >= 0";
        
        try (Connection conn = veriTabani.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, quantityChange);
            pstmt.setInt(2, bookId);
            pstmt.setInt(3, quantityChange);
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating stock: " + e.getMessage());
        }
        return false;
    }
    public boolean updateStock1(int bookId, int quantityChange) throws SQLException {
        String sql = "UPDATE books SET quantity = quantity + ? WHERE book_id = ? AND quantity + ? >= 0";
        
        try (Connection conn = veriTabani.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, quantityChange);
            pstmt.setInt(2, bookId);
            pstmt.setInt(3, quantityChange);
            
            return pstmt.executeUpdate() > 0;
        }
    }
    public Book getBookById(int bookId) {
        String sql = "SELECT * FROM books WHERE book_id = ?";
        
        try (Connection conn = veriTabani.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, bookId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Book book = new Book();
                    book.setBookId(rs.getInt("book_id"));
                    book.setTitle(rs.getString("title"));
                    book.setAuthor(rs.getString("author"));
                    book.setIsbn(rs.getString("isbn"));
                    book.setPrice(rs.getDouble("price"));
                    book.setQuantity(rs.getInt("quantity"));
                    book.setCategory(rs.getString("category"));
                    book.setPublishYear(rs.getInt("publish_year"));
                    return book;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting book by ID: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
    
    public boolean updateStock11(int bookId, int quantityChange) {
        String sql = "UPDATE books SET quantity = quantity + ? WHERE book_id = ?";
        
        try (Connection conn = veriTabani.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, quantityChange);
            pstmt.setInt(2, bookId);
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;   
        } catch (SQLException e) {
            System.err.println("Error updating stock: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
	public Customer read(int id) {
		return null;
	}
}