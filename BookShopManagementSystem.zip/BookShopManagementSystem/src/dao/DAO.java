package dao;

import java.util.List;

import model.Book;
import model.Customer;

public interface DAO <T> {
    boolean create(T entity);
    Customer read(int id);
    Book read1(int id); 
    List<T> readAll();
    boolean update(T entity);
    boolean delete(int id);
}
