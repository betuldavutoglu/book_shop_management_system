package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import database.veriTabani;
import model.Order;
import model.OrderItem;

public class OrderDAO {
	public boolean create(Order order) {
	    System.out.println("=== OrderDAO.create() çağrıldı ===");
	    
	    String query = "INSERT INTO orders (customer_id, total_amount, status) VALUES (?, ?, ?)";
	    
	    try (Connection conn = veriTabani.getConnection();
	        PreparedStatement pstmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
	        
	        System.out.println("Müşteri ID: " + order.getCustomerId());
	        System.out.println("Toplam Tutar: " + order.getTotalAmount());
	        System.out.println("Durum: " + order.getStatus());
	        
	        pstmt.setInt(1, order.getCustomerId());
	        pstmt.setDouble(2, order.getTotalAmount());
	        pstmt.setString(3, order.getStatus());
	        
	        int affectedRows = pstmt.executeUpdate();
	        System.out.println("Etkilenen satır sayısı: " + affectedRows);
	        
	        if (affectedRows > 0) {
	            try (ResultSet rs = pstmt.getGeneratedKeys()) {
	                if (rs.next()) {
	                    int orderId = rs.getInt(1);
	                    order.setOrderId(orderId);
	                    System.out.println("Oluşturulan Sipariş ID: " + orderId);

	                    if (order.getItems() != null && !order.getItems().isEmpty()) {
	                        saveOrderItems(orderId, order.getItems(), conn);
	                        System.out.println("Sipariş öğeleri kaydedildi");
	                    }
	                    return true;
	                }
	            }
	        }
	        return false;
	    } catch (SQLException e) {
	        System.err.println("OrderDAO.create() hatası: " + e.getMessage());
	        System.err.println("SQL State: " + e.getSQLState());
	        System.err.println("Error Code: " + e.getErrorCode());
	        e.printStackTrace();
	        return false;
	    }
	}
	private void saveOrderItems(int orderId, List<OrderItem> items, Connection conn) throws SQLException {
	    System.out.println("=== saveOrderItems çağrıldı ===");
	    System.out.println("Kaydedilecek öğe sayısı: " + items.size());
	    
	    String query = "INSERT INTO order_items (order_id, book_id, quantity, unit_price) VALUES (?, ?, ?, ?)";
	    
	    try (PreparedStatement pstmt = conn.prepareStatement(query)) {
	        for (OrderItem item : items) {
	            System.out.println("Öğe - Kitap ID: " + item.getBookId() + 
	                             ", Miktar: " + item.getQuantity() + 
	                             ", Fiyat: " + item.getUnitPrice());
	            
	            pstmt.setInt(1, orderId);
	            pstmt.setInt(2, item.getBookId());
	            pstmt.setInt(3, item.getQuantity());
	            pstmt.setDouble(4, item.getUnitPrice());
	            pstmt.addBatch();
	        }
	        int[] results = pstmt.executeBatch();
	        System.out.println("Batch sonuçları: " + Arrays.toString(results));
	        
	    } catch (SQLException e) {
	        System.err.println("saveOrderItems hatası: " + e.getMessage());
	        throw e;
	    }
	}
    public List<Order> readAll() {
        String sql = "SELECT o.*, CONCAT(c.first_name, ' ', c.last_name) as customer_name " +
                    "FROM orders o " +
                    "LEFT JOIN customers c ON o.customer_id = c.customer_id " +
                    "ORDER BY o.order_id DESC";
        
        List<Order> orders = new ArrayList<>();
        try (Connection conn = veriTabani.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Order order = new Order();
                order.setOrderId(rs.getInt("order_id"));
                order.setCustomerId(rs.getInt("customer_id"));
                order.setCustomerName(rs.getString("customer_name"));
                
                Timestamp ts = rs.getTimestamp("order_date");
                if (ts != null) order.setOrderDate(ts.toLocalDateTime());
                
                order.setTotalAmount(rs.getDouble("total_amount"));
                order.setStatus(rs.getString("status"));
                orders.add(order);
            }
        } catch (SQLException e) {
            System.err.println("Siparişler listelenirken hata: " + e.getMessage());
        }
        return orders;
    }
    public Order read(int id) {
        String sql = "SELECT o.*, CONCAT(c.first_name, ' ', c.last_name) as customer_name " +
                    "FROM orders o " +
                    "LEFT JOIN customers c ON o.customer_id = c.customer_id " +
                    "WHERE o.order_id = ?";
        
        try (Connection conn = veriTabani.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Order order = new Order();
                    order.setOrderId(rs.getInt("order_id"));
                    order.setCustomerId(rs.getInt("customer_id"));
                    order.setCustomerName(rs.getString("customer_name"));
                    Timestamp ts = rs.getTimestamp("order_date");
                    if (ts != null) order.setOrderDate(ts.toLocalDateTime());
                    order.setTotalAmount(rs.getDouble("total_amount"));
                    order.setStatus(rs.getString("status"));
                    order.setItems(getOrderItems(id));
                    return order;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public List<OrderItem> getOrderItems(int orderId) {
        String sql = "SELECT oi.*, b.title as book_title FROM order_items oi " +
                    "LEFT JOIN books b ON oi.book_id = b.book_id WHERE oi.order_id = ?";
        List<OrderItem> items = new ArrayList<>();
        try (Connection conn = veriTabani.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, orderId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    OrderItem item = new OrderItem();
                    item.setItemId(rs.getInt("order_item_id"));
                    item.setOrderId(rs.getInt("order_id"));
                    item.setBookId(rs.getInt("book_id"));
                    item.setBookTitle(rs.getString("book_title"));
                    item.setQuantity(rs.getInt("quantity"));
                    item.setUnitPrice(rs.getDouble("unit_price"));
                    item.setTotalPrice(rs.getDouble("total_price"));
                    items.add(item);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return items;
    }
    public boolean delete(int id) {
        try (Connection conn = veriTabani.getConnection()) {
            conn.setAutoCommit(false);
            try {
                try (PreparedStatement ps1 = conn.prepareStatement("DELETE FROM order_items WHERE order_id = ?")) {
                    ps1.setInt(1, id);
                    ps1.executeUpdate();
                }
                try (PreparedStatement ps2 = conn.prepareStatement("DELETE FROM orders WHERE order_id = ?")) {
                    ps2.setInt(1, id);
                    int res = ps2.executeUpdate();
                    conn.commit();
                    return res > 0;
                }
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean updateOrderStatus(int orderId, String status) {
        String sql = "UPDATE orders SET status = ? WHERE order_id = ?";
        try (Connection conn = veriTabani.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, status);
            pstmt.setInt(2, orderId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean update(Order order) {
        String sql = "UPDATE orders SET total_amount = ?, status = ? WHERE order_id = ?";
        try (Connection conn = veriTabani.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setDouble(1, order.getTotalAmount());
            pstmt.setString(2, order.getStatus());
            pstmt.setInt(3, order.getOrderId());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public List<Order> getOrdersByCustomer(int customerId) {
        List<Order> all = readAll();
        List<Order> filtered = new ArrayList<>();
        for(Order o : all) {
            if(o.getCustomerId() == customerId) filtered.add(o);
        }
        return filtered;
    }
}