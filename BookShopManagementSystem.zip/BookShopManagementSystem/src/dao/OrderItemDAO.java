package dao;

public class OrderItemDAO {

}
