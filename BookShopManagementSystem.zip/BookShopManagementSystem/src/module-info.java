/**
 * 
 */
/**
 * 
 */
module BookShopManagementSystem {
	requires java.sql;
	requires java.desktop;
}